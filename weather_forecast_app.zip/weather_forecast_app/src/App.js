import "./App.css";
import WeekContainer from "./components/WeekContainer";
import HourContainer from "./components/HourContainer";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function App() {
  return (
    // <div>
    //   <WeekContainer />
    // </div>
    <Router>
      <Routes>
        <Route path="/" element={<WeekContainer />}></Route>
        <Route path="/:nameofday" element={<HourContainer />}></Route>
      </Routes>
    </Router>
    // <div className="App">
    //   <header className="App-header">
    //     <div class="dashboardContainer">
    //       <div class="mainScreen">
    //         <div class="header vcenter">
    //           <div class="logoHold center">
    //             <img
    //               src="https://i.imgrpost.com/imgr/2018/01/28/mostlycloudy.png"
    //               alt="mostlycloudy.png"
    //               border="0"
    //             />
    //           </div>
    //           <div class="logoName center">Météo</div>
    //         </div>
    //         <div class="todayLabel center">Today's Weather</div>
    //         <div class="city">Delhi, 29-Jan Mon</div>
    //         <div class="sunHolder center">
    //           <div class="sun"></div>
    //         </div>
    //         <div class="infotab center">
    //           <div class="temprature">
    //             <div class="tempvalue center">21&deg;</div>
    //             <div class="condition center">Sunny</div>
    //           </div>
    //           <div class="details">
    //             <div class="detail">Mostly Clear</div>
    //             <div class="detail">Humidity : 65%</div>
    //             <div class="detail">Wind : 2 km/h N-E</div>
    //             <div class="detail">Min: 11&deg; &nbsp;&nbsp;Max: 23&deg;</div>
    //           </div>
    //         </div>
    //         <div class="future vcenter">
    //           <div class="day vcenter">
    //             <h5>Tue</h5>
    //             <img
    //               src="http://i.imgrpost.com/imgr/2017/08/01/006-sunny.png"
    //               alt="006-sunny.png"
    //               border="0"
    //             />
    //             <div class="temp">20&deg;</div>
    //           </div>
    //           <div class="day vcenter">
    //             <h5>Wed</h5>
    //             <img
    //               src="http://i.imgrpost.com/imgr/2017/08/01/009-sky.png"
    //               alt="009-sky.png"
    //               border="0"
    //             />
    //             <div class="temp">21&deg;</div>
    //           </div>
    //           <div class="day vcenter">
    //             <h5>Thu</h5>
    //             <img
    //               src="http://i.imgrpost.com/imgr/2017/08/01/008-summer-rain.png"
    //               alt="008-summer-rain.png"
    //               border="0"
    //             />
    //             <div class="temp">23&deg;</div>
    //           </div>
    //           <div class="day vcenter">
    //             <h5>Fri</h5>
    //             <img
    //               src="http://i.imgrpost.com/imgr/2017/08/01/009-sky.png"
    //               alt="009-sky.png"
    //               border="0"
    //             />
    //             <div class="temp">22&deg;</div>
    //           </div>
    //         </div>
    //       </div>
    //       <div class="widgets">
    //         <div class="worldweather">
    //           <div class="title">World's Weather Today</div>
    //           <div class="future vcenter">
    //             <div class="day vcenter">
    //               <h5>Doha</h5>
    //               <img
    //                 src="http://i.imgrpost.com/imgr/2017/08/01/006-sunny.png"
    //                 alt="006-sunny.png"
    //                 border="0"
    //               />
    //               <div class="temp">12°C</div>
    //             </div>
    //             <div class="day vcenter">
    //               <h5>Chicago</h5>
    //               <img
    //                 src="http://i.imgrpost.com/imgr/2017/08/01/009-sky.png"
    //                 alt="009-sky.png"
    //                 border="0"
    //               />
    //               <div class="temp">1°C</div>
    //             </div>
    //             <div class="day vcenter">
    //               <h5>Dublin</h5>
    //               <img
    //                 src="http://i.imgrpost.com/imgr/2017/08/01/009-sky.png"
    //                 alt="009-sky.png"
    //                 border="0"
    //               />
    //               <div class="temp">12°C</div>
    //             </div>
    //             <div class="day vcenter">
    //               <h5>Stockholm</h5>
    //               <img
    //                 src="https://i.imgrpost.com/imgr/2018/01/28/raining-1.png"
    //                 alt="raining-1.png"
    //                 border="0"
    //               />
    //               <div class="temp">14°C</div>
    //             </div>
    //             <div class="day vcenter">
    //               <h5>Sydney</h5>
    //               <img
    //                 src="https://i.imgrpost.com/imgr/2018/01/28/calm-1.png"
    //                 alt="calm-1.png"
    //                 border="0"
    //               />
    //               <div class="temp">22&deg;</div>
    //             </div>
    //           </div>
    //         </div>
    //       </div>
    //     </div>
    //   </header>
    // </div>
  );
}

export default App;
