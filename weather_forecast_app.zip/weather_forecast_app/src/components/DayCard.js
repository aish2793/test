import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import HourContainer from "./HourContainer";

var moment = require("moment");

const DayCard = ({ reading }) => {
  let newDate = new Date();
  const weekday = reading.dt * 1000;
  newDate.setTime(weekday);
  const imgURL = `owf owf-${reading.weather[0].id} owf-5x`;
  return (
    <div className="col-sm-2">
      <div className="card">
        <Link
          to={{
            pathname: `/${moment(newDate).format("dddd")}`,
            date: reading.dt_txt,
          }}
        >
          <h3 className="card-title">{moment(newDate).format("dddd")}</h3>
        </Link>
        {/* <Link to={`/${moment(newDate).format("dddd")}`}>
          <h3 className="card-title">{moment(newDate).format("dddd")}</h3>
        </Link> */}
        <p className="text-muted">
          {moment(newDate).format("MMMM Do, h:mm a")}
        </p>

        <i className={imgURL}></i>
        <h2>{Math.round(reading.main.temp)} °F</h2>
        <p className="text-muted">
          {"   "}H:
          {Math.round(reading.main.temp_max)}°F {"           "}
          L:{Math.round(reading.main.temp_min)}°F
        </p>
        <div className="card-body">
          <p className="card-text">{reading.weather[0].description}</p>
        </div>
      </div>
    </div>
  );
};

export default DayCard;
