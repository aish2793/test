import React, { useState } from "react";
import HourCard from "./HourCard";
import { useLocation } from "react-router-dom";

var moment = require("moment");

const HourContainer = () => {
  const [dailyData, setDailyData] = useState([]);
  const location = useLocation();
  const weatherURL = `http://api.openweathermap.org/data/2.5/forecast?zip=11102&units=imperial&APPID=aa4fbe942f183846e2f67155da431f28`;
  console.log(location.date);
  console.log("HEREEE");
  fetch(weatherURL)
    .then((res) => res.json())
    .then((data) => {
      const dailyData = data.list.filter((reading) =>
        reading.dt_txt.includes(moment(location.date).format("YYYY-MM-DD"))
      );
      setDailyData(dailyData);
    });
  const formatHourCards = () => {
    return dailyData.map((reading, index) => (
      <HourCard reading={reading} key={index} />
    ));
  };
  return <div className="row justify-content-center">{formatHourCards()}</div>;
};

// class HourContainer extends React.Component {
//   state = {
//     fullData: [],
//     dailyData: [],
//   };

//   componentDidMount = () => {
//     const weatherURL = `http://api.openweathermap.org/data/2.5/forecast?zip=11102&units=imperial&APPID=aa4fbe942f183846e2f67155da431f28`;
//     console.log(useLocation.date);
//     console.log("HEREEE");
//     fetch(weatherURL)
//       .then((res) => res.json())
//       .then((data) => {
//         const dailyData = data.list.filter((reading) =>
//           reading.dt_txt.includes(moment(useLocation.date).format("YYYY-MM-DD"))
//         );
//         this.setState(
//           {
//             fullData: data.list,
//             dailyData: dailyData,
//           },
//           () => console.log(this.state)
//         );
//       });
//   };

//   formatHourCards = () => {
//     return this.state.dailyData.map((reading, index) => (
//       <HourCard reading={reading} key={index} />
//     ));
//   };

//   render() {
//     return (
//       <div className="row justify-content-center">{this.formatHourCards()}</div>
//     );
//   }
// }

export default HourContainer;
