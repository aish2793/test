import React from "react";
import DayCard from "./DayCard";
class WeatherApp extends React.Component {
  render() {
    return (
      <div className="container">
        <h1 className="display-3 jumbotron">5-Day Forecast</h1>
        <h5 className="display-5 text-muted">New York, US</h5>
      </div>
    );
  }
}

export default WeatherApp;
